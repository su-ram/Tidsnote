package com.example.youngeun.parentapp;


import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Login extends AppCompatActivity {

    MaterialButton button;
    TextInputEditText id, pw;
    ImageView logo;
    public ArrayList<String> loginArrayList;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        button = (MaterialButton) findViewById(R.id.login_btn);
        id = (TextInputEditText) findViewById(R.id.id);
        pw = (TextInputEditText) findViewById(R.id.password);
        //logo = (ImageView) findViewById(R.id.logo);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                loginData newLogin = new loginData();
                newLogin.setLoginID(id.getText().toString());
                newLogin.setLoginPW(pw.getText().toString());

                try_login("login",newLogin);


                if(loginArrayList.size()==3){
                    String p_id=loginArrayList.get(0);
                    String s_id =loginArrayList.get(2);

                    Log.i("p_id",loginArrayList.get(0));
                    Log.i("s_id",loginArrayList.get(2));

                    Intent intent=new Intent(getApplicationContext(),MainActivity.class);
                    intent.putExtra("parentID",p_id);
                    intent.putExtra("studentID",s_id);

                    startActivity(intent);

                }
                else{
                    Toast.makeText(getApplicationContext(),"Login Failed",Toast.LENGTH_LONG).show();
                }

                id.setText("");
                pw.setText("");



            }
        });


    }

    public byte[] getByteArrayFromDrawable(Drawable d) {
        //이미지 저장하기

        Bitmap bitmap = ((BitmapDrawable) d).getBitmap();
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
        byte[] data = stream.toByteArray();

        return data;
    }

    public Bitmap getImage(byte[] b) {
        Bitmap bitmap = BitmapFactory.decodeByteArray(b, 0, b.length);
        return bitmap;
    }

    public void try_login(String type, @Nullable Object obj) {


        Client client = new Client(this, type);
        client.setData(obj);
        client.start();
        try {
            client.join();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
