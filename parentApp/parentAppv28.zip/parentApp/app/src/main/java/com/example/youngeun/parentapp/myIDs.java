package com.example.youngeun.parentapp;

public class myIDs {

    public static String s_id;
    public static String p_id;

}
